const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const port = process.env.PORT || 3001;

app.use(bodyParser.json());
app.use(cors());

// Dummy data for foods
const foods = [
  { id: 1, name: 'Mie Ayam', calories: 1035, fat: 14.92, carbs: 19.55, protein: 24.01 },
  { id: 2, name: 'Mie Ayam bakso', calories: 1035, fat: 14.92, carbs: 19.55, protein: 24.01 },
  { id: 3, name: 'Mie Ayam ceker', calories: 1035, fat: 14.92, carbs: 19.55, protein: 24.01 },
  { id: 4, name: 'Mie Ayam jamur', calories: 1035, fat: 14.92, carbs: 19.55, protein: 24.01 }
];

// Endpoint for searching food with GET
app.get('/search_food', (req, res) => {
  const query = req.query.q.toLowerCase();
  const results = foods.filter(food => food.name.toLowerCase().includes(query));
  res.json(results);
});

// Endpoint for searching food with POST
app.post('/search_food', (req, res) => {
  const query = req.body.query.toLowerCase();
  const results = foods.filter(food => food.name.toLowerCase().includes(query));
  res.json(results);
});

// Endpoint for food details with GET
app.get('/food_details/:id', (req, res) => {
  console.log('Received request for food ID:', req.params.id); // Logging ID
  const foodId = parseInt(req.params.id, 10);
  const food = foods.find(f => f.id === foodId);
  if (food) {
    res.json(food);
  } else {
    res.status(404).json({ error: 'Food not found' });
  }
});

// Endpoint for food details with POST
app.post('/food_details', (req, res) => {
  const foodId = parseInt(req.body.id, 10);
  const food = foods.find(f => f.id === foodId);
  if (food) {
    res.json(food);
  } else {
    res.status(404).json({ error: 'Food not found' });
  }
});

app.listen(port, () => {
  console.log(`Food API is running at http://localhost:${port}`);
});
