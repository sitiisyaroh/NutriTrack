const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

// Koneksi ke MongoDB
mongoose.connect('mongodb+srv://Dbnut:123qwe123qwe@dbnut.h9mi8ea.mongodb.net/?retryWrites=true&w=majority&appName=Dbnut', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log('Connected to MongoDB');
    })
    .catch(err => {
        console.error('Error connecting to MongoDB:', err);
    });

// Skema dan Model Pengguna
const UserSchema = new mongoose.Schema({
    fullName: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});

const User = mongoose.model('User', UserSchema);

// Rute Root
app.get('/', (req, res) => {
    res.send('Server berjalan dengan baik!');
});

// API Signup
app.post('/signup', async (req, res) => {
    const { fullName, email, password } = req.body;

    if (!fullName || !email || !password) {
        return res.status(400).json({ message: 'Nama lengkap, email, dan password harus diisi!' });
    }

    if (password.length < 6) {
        return res.status(400).json({ message: 'Maaf, password kurang dari 6 karakter.' });
    }

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'Pengguna sudah terdaftar!' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ fullName, email, password: hashedPassword });

        await user.save();
        res.status(201).json({ message: 'Pendaftaran berhasil!' });
    } catch (error) {
        console.error('Error during signup:', error);
        res.status(500).json({ message: 'Terjadi kesalahan pada server.' });
    }
});

// API Login
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: 'Email dan Password harus diisi!' });
    }

    try {
        const user = await User.findOne({ email });
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ message: 'Kredensial tidak valid!' });
        }

        res.status(200).json({ message: 'Login berhasil!' });
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({ message: 'Terjadi kesalahan pada server.' });
    }
});

// Menjalankan Server
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
    console.log(`Server berjalan di port ${PORT}`);
});
