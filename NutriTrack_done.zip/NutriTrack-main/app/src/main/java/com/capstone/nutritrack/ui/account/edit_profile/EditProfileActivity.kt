package com.capstone.nutritrack.ui.account.edit_profile

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.capstone.nutritrack.R

class EditProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)
    }
}