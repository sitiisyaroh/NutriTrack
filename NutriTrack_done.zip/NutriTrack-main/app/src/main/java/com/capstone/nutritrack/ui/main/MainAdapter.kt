package com.capstone.nutritrack.ui.main

class MainAdapter {
}