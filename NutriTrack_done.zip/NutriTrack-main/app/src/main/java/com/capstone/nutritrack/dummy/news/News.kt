package com.capstone.nutritrack.dummy.news

data class News(
    val id: Int,
    val title: String,
    val description: String,
    val author: String,
    val image: String
)