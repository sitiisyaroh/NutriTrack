const mongoose = require('mongoose');

const SetGoalsSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    gender: { type: String, required: true },
    dateOfBirth: { type: Date, required: true },
    height: { type: Number, required: true },
    weight: { type: Number, required: true },
    goalWeight: { type: Number, required: true },
    bmi: { type: Number, required: true },
    bmiCategory: { type: String, required: true },
    dailyCalorieNeeds: { type: Number, required: true }
});

module.exports = mongoose.model('SetGoals', SetGoalsSchema);
