const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const xlsx = require('xlsx');

const app = express();
const port = process.env.PORT || 8080;

app.use(bodyParser.json());
app.use(cors());

// Koneksi ke MongoDB
mongoose.connect('mongodb+srv://Dbnut:123qwe123qwe@dbnut.h9mi8ea.mongodb.net/?retryWrites=true&w=majority&appName=Dbnut', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log('Connected to MongoDB');
    })
    .catch(err => {
        console.error('Error connecting to MongoDB:', err);
    });

// Skema dan Model Pengguna
const UserSchema = new mongoose.Schema({
    fullName: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});

const User = mongoose.model('User', UserSchema);

// Skema dan Model Asupan Makanan
const FoodIntakeSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    foodName: { type: String, required: true },
    calories: { type: Number, required: true },
    date: { type: Date, default: Date.now }
});

const FoodIntake = mongoose.model('FoodIntake', FoodIntakeSchema);

// Skema dan Model Makanan
const FoodSchema = new mongoose.Schema({
    id: { type: Number, required: true, unique: true },
    name: { type: String, required: true },
    calories: { type: Number, required: true },
    fat: { type: Number, required: true },
    carbs: { type: Number, required: true },
    protein: { type: Number, required: true }
});

const Food = mongoose.model('Food', FoodSchema);

// Mengimpor Model SetGoals
const SetGoals = require('./models/SetGoals');

// Rute Root
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// API Signup
app.post('/api/signup', async (req, res) => {
    const { fullName, email, password } = req.body;

    if (!fullName || !email || !password) {
        return res.status(400).json({ message: 'Nama lengkap, email, dan password harus diisi!' });
    }

    if (password.length < 6) {
        return res.status(400).json({ message: 'Maaf, password kurang dari 6 karakter.' });
    }

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'Pengguna sudah terdaftar!' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ fullName, email, password: hashedPassword });

        const newUser = await user.save();
        res.status(201).json({ message: 'Pendaftaran berhasil!', userId: newUser._id });
    } catch (error) {
        console.error('Error during signup:', error);
        res.status(500).json({ message: 'Terjadi kesalahan pada server.' });
    }
});

// API Login
app.post('/api/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: 'Email dan Password harus diisi!' });
    }

    try {
        const user = await User.findOne({ email });
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ message: 'Kredensial tidak valid!' });
        }

        res.status(200).json({ message: 'Login berhasil!', userId: user._id });
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({ message: 'Terjadi kesalahan pada server.' });
    }
});

// Endpoint untuk menambahkan data makanan dari file Excel
app.post('/api/add-foods-from-excel', async (req, res) => {
    try {
        const filePath = path.join(__dirname, 'makanan.xlsx');
        const workbook = xlsx.readFile(filePath);
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const data = xlsx.utils.sheet_to_json(sheet);

        // Hapus semua data lama sebelum menambahkan data baru
        await Food.deleteMany({});

        // Tambahkan data baru dari file Excel
        await Food.insertMany(data);
        res.status(201).send('Data added successfully from Excel file');
    } catch (error) {
        res.status(400).send(error.message);
    }
});

// Endpoint untuk menambahkan data makanan dari file Excel menggunakan GET
app.get('/api/add-foods-from-excel', async (req, res) => {
    try {
        const filePath = path.join(__dirname, 'makanan.xlsx');
        const workbook = xlsx.readFile(filePath);
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const data = xlsx.utils.sheet_to_json(sheet);

        // Hapus semua data lama sebelum menambahkan data baru
        await Food.deleteMany({});

        // Tambahkan data baru dari file Excel
        await Food.insertMany(data);
        res.status(201).send('Data added successfully from Excel file');
    } catch (error) {
        res.status(400).send(error.message);
    }
});




// Endpoint untuk mencari makanan dengan GET
app.get('/api/search_food', (req, res) => {
    const query = req.query.q.toLowerCase();
    Food.find({ name: { $regex: query, $options: 'i' } })
        .then(foods => res.json(foods))
        .catch(err => res.status(500).json({ message: err.message }));
});

// Endpoint untuk mencari makanan dengan POST
app.post('/api/search_food', (req, res) => {
    const query = req.body.query.toLowerCase();
    Food.find({ name: { $regex: query, $options: 'i' } })
        .then(foods => res.json(foods))
        .catch(err => res.status(500).json({ message: err.message }));
});

// Endpoint untuk detail makanan dengan GET
app.get('/api/food_details/:id', (req, res) => {
    const foodId = parseInt(req.params.id, 10);
    Food.findOne({ id: foodId })
        .then(food => {
            if (food) {
                res.json(food);
            } else {
                res.status(404).json({ error: 'Makanan tidak ditemukan' });
            }
        })
        .catch(err => res.status(500).json({ message: err.message }));
});

// Endpoint untuk detail makanan dengan POST
app.post('/api/food_details', (req, res) => {
    const foodId = parseInt(req.body.id, 10);
    Food.findOne({ id: foodId })
        .then(food => {
            if (food) {
                res.json(food);
            } else {
                res.status(404).json({ error: 'Makanan tidak ditemukan' });
            }
        })
        .catch(err => res.status(500).json({ message: err.message }));
});

// Endpoint untuk menambah asupan makanan
app.post('/api/foodIntake', async (req, res) => {
    const { userId, foodName, calories } = req.body;

    if (!userId || !foodName || !calories) {
        return res.status(400).json({ message: 'User ID, nama makanan, dan kalori harus diisi!' });
    }

    try {
        const foodIntake = new FoodIntake({ userId, foodName, calories });
        const newFoodIntake = await foodIntake.save();
        res.status(201).json(newFoodIntake);
    } catch (error) {
        console.error('Error during food intake:', error);
        res.status(500).json({ message: 'Terjadi kesalahan pada server.' });
    }
});

// Endpoint untuk mendapatkan asupan makanan berdasarkan userId
app.get('/api/foodIntake/:userId', async (req, res) => {
    try {
        const foodIntakes = await FoodIntake.find({ userId: req.params.userId });
        res.json(foodIntakes);
    } catch (error) {
        console.error('Error getting food intake:', error);
        res.status(500).json({ message: 'Terjadi kesalahan pada server.' });
    }
});

// Fungsi untuk menghitung BMI
function calculateBMI(weight, height) {
    return weight / ((height / 100) ** 2);
}

// Fungsi untuk mendapatkan kategori BMI
function getBMICategory(bmi) {
    if (bmi < 18.5) return 'Underweight';
    if (bmi >= 18.5 && bmi < 24.9) return 'Normal weight';
    if (bmi >= 25 && bmi < 29.9) return 'Overweight';
    if (bmi >= 30 && bmi < 34.9) return 'Obesity Class I';
    if (bmi >= 35 && bmi < 39.9) return 'Obesity Class II';
    return 'Obesity Class III';
}

// Fungsi untuk menghitung kebutuhan kalori harian
function calculateDailyCalorieNeeds(gender, weight, height, age) {
    if (gender === 'Man') {
        return 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age);
    } else {
        return 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age);
    }
}

// Rute untuk menyimpan tujuan pengguna
app.post('/api/setGoals', async (req, res) => {
    const { userId, gender, dateOfBirth, height, weight, goalWeight } = req.body;

    console.log('Request Body:', req.body);

    const age = new Date().getFullYear() - new Date(dateOfBirth).getFullYear();
    const bmi = calculateBMI(weight, height);
    const bmiCategory = getBMICategory(bmi);
    const dailyCalorieNeeds = calculateDailyCalorieNeeds(gender, weight, height, age);

    const setGoals = new SetGoals({
        userId,
        gender,
        dateOfBirth,
        height,
        weight,
        goalWeight,
        bmi,
        bmiCategory,
        dailyCalorieNeeds
    });

    try {
        const newSetGoals = await setGoals.save();
        console.log('New set goals saved:', newSetGoals);
        res.status(201).json(newSetGoals);
    } catch (err) {
        console.error('Error saving set goals:', err);
        res.status(400).json({ message: err.message });
    }
});

// Rute untuk mendapatkan tujuan pengguna berdasarkan userId
app.get('/api/setGoals/:userId', async (req, res) => {
    try {
        const setGoals = await SetGoals.find({ userId: req.params.userId });
        if (!setGoals) {
            return res.status(404).json({ message: 'Tujuan tidak ditemukan' });
        }
        res.json(setGoals);
    } catch (error) {
        console.error('Error getting goals:', error);
        res.status(500).json({ message: 'Terjadi kesalahan pada server.' });
    }
});

// Menjalankan Server
app.listen(port, () => {
    console.log(`Server berjalan di http://localhost:${port}`);
});
