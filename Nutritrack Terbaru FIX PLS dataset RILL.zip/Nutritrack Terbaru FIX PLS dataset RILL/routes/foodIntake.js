const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

// Skema dan Model Asupan Makanan
const FoodIntakeSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    foodName: { type: String, required: true },
    calories: { type: Number, required: true },
    date: { type: Date, default: Date.now }
});

const FoodIntake = mongoose.model('FoodIntake', FoodIntakeSchema);

// Endpoint untuk menambah asupan makanan
router.post('/', async (req, res) => {
    const { userId, foodName, calories } = req.body;

    if (!userId || !foodName || !calories) {
        return res.status(400).json({ message: 'User ID, nama makanan, dan kalori harus diisi!' });
    }

    try {
        const foodIntake = new FoodIntake({ userId, foodName, calories });
        const newFoodIntake = await foodIntake.save();
        res.status(201).json(newFoodIntake);
    } catch (error) {
        console.error('Error during food intake:', error);
        res.status(500).json({ message: 'Terjadi kesalahan pada server.' });
    }
});

// Endpoint untuk mendapatkan asupan makanan berdasarkan userId
router.get('/:userId', async (req, res) => {
    try {
        const foodIntakes = await FoodIntake.find({ userId: req.params.userId });
        res.json(foodIntakes);
    } catch (error) {
        console.error('Error getting food intake:', error);
        res.status(500).json({ message: 'Terjadi kesalahan pada server.' });
    }
});

module.exports = router;
