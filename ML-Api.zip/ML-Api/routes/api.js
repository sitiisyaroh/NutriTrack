const express = require('express');
const router = express.Router();
const Model = require('../models/Model');

// GET all models
router.get('/models', async (req, res) => {
    try {
        const models = await Model.find();
        res.json(models);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// POST a new model
router.post('/models', async (req, res) => {
    const model = new Model({
        module: req.body.module,
        class_name: req.body.class_name,
        config: req.body.config,
        compile_config: req.body.compile_config,
    });
    try {
        const newModel = await model.save();
        res.status(201).json(newModel);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

module.exports = router;
