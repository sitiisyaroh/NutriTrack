const mongoose = require('mongoose');

const ModelSchema = new mongoose.Schema({
    module: { type: String, required: true },
    class_name: { type: String, required: true },
    config: { type: Object, required: true },
    compile_config: { type: Object, required: true },
});

module.exports = mongoose.model('Model', ModelSchema);

