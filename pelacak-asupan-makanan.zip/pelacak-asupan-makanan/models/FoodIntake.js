// models/FoodIntake.js

const mongoose = require('mongoose');

const FoodIntakeSchema = new mongoose.Schema({
    date: {
        type: Date,
        required: true
    },
    food: {
        type: String,
        required: true
    },
    calories: {
        type: Number,
        required: true
    },
    servings: {
        type: String,
        required: true
    }
});

module.exports = mongoose.model('FoodIntake', FoodIntakeSchema);
