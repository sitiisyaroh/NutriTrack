// app.js

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.json());

// Import rute
const foodIntakeRoutes = require('./routes/foodIntake');
app.use('/api/foodIntake', foodIntakeRoutes);

// Koneksi ke MongoDB
mongoose.connect('mongodb://localhost:27017/foodIntakeDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const db = mongoose.connection;
db.on('error', (error) => console.error(error));
db.once('open', () => console.log('Terhubung ke Database MongoDB'));

// Menjalankan server
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Server berjalan di port ${PORT}`));
