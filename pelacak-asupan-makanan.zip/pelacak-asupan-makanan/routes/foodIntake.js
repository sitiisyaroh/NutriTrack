// routes/foodIntake.js

const express = require('express');
const router = express.Router();
const FoodIntake = require('../models/FoodIntake');

// GET semua riwayat asupan makanan
router.get('/', async (req, res) => {
    try {
        const foodIntake = await FoodIntake.find();
        res.json(foodIntake);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// POST data asupan makanan baru
router.post('/', async (req, res) => {
    const foodIntake = new FoodIntake({
        date: req.body.date,
        food: req.body.food,
        calories: req.body.calories,
        servings: req.body.servings
    });

    try {
        const newFoodIntake = await foodIntake.save();
        res.status(201).json(newFoodIntake);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

module.exports = router;
